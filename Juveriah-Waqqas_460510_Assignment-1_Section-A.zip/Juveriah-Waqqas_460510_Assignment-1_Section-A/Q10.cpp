#include<iostream>
using namespace std;
int main()
{
	int array[6]={};
	cout<<"Input the array : "<<endl;
	for(int i=0; i<6; i++)
	{
		cin>>array[i];
	}
	
	int iteration=0;
	while(iteration<6-1)
	{
		for(int i=0; i<6-iteration; i++)
		{
			if (array[i]>array[i+1])
			{
				int saver = array[i];
				array[i]=array[i+1];
				array[i+1]=saver;
			}
		}
		
		iteration++;
	}
	
	cout<<"The sorted array is : ";
	for(int i=0; i<5; i++)
	{
		cout<<array[i]<<" , ";
	}
	cout<<array[5];
	
return 0;
}


