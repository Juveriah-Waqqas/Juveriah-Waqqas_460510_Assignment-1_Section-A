#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int N, prime;
	bool is_prime; 
	cout<<"Input a positive integer : ";
	cin>>N;
	if(N>=0)
	{
		int i=1;
		while(i<N)
		{
			is_prime = true;
			for(int j=2; j<=sqrt(i); j++)	
			
			{ if ( i % j == 0) {is_prime=false; break;}
		}
			if(is_prime)
			{
			prime = i;
			}
		
		i++;
		}
		
		cout<<"The largest prime number smaller than "<<N<<" is : "<<prime;
	
	}
	
else
{cout<<"Invalid Input";}
	
return 0;
	
}
