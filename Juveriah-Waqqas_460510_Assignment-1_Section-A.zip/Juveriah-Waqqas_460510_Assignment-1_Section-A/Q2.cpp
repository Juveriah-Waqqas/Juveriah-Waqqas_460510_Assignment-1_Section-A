#include<iostream>
using namespace std;
int main()
{
	int x=5;
	int y=10;
	
	if(x==5)
		if(y==10)
			cout<<"x is 5 and y is 10"<<endl;
	else
		cout<<"x is not 5";
return 0;
} 
