#include<iostream>
using namespace std;
int main()
{
	bool triplet_found=false;
	
	int X;
	cout<<"Input the Integer : ";
	cin>>X;
	
	int size;
	cout<<"Input the size of your array : ";
	cin>>size;
	
	int array[size]={};
	cout<<"Input the array : "<<endl;
	for(int i=0; i<size; i++)
	{
		cin>>array[i];
	}
	
	for(int i=0; i<size-2; i++)
	{
		for(int j=i+1; j<size-1; j++)
		{
			for(int k=j+1; k<size; k++)
			{
				if(array[i]+array[j]+array[k]==X)
				{
					cout<<array[i]<<" + "<<array[j]<<" + "<<array[k]<<" = "<<X<<endl;
					triplet_found=true;
				}
			}
		}
	}
	
	if(triplet_found!=true)
	{
		cout<<"No Triplet found";
	}
	
return 0;
}


