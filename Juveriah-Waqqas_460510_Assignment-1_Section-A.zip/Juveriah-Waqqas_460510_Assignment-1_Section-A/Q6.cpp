#include<iostream>
using namespace std;
int main()
{
	int dividend, divisor, remainder=0, quotient=0;
	cout<<"Input the dividend : ";
	cin>>dividend;
	cout<<"Input the divisor : ";
	cin>>divisor;
	
	if(dividend >= divisor && divisor!=0)
	{
		for(remainder=dividend; remainder>=divisor; remainder -=divisor)
		{
			quotient++;
		}
		
		cout<<"the operation "<<dividend<<"/"<<divisor<<" gives us "<<endl;
		cout<<"Remainder = "<<remainder<<endl<<"Quotient = "<<quotient;
	}
	else
	{ cout<<"Operation Invalid!";}
	
return 0;
}


