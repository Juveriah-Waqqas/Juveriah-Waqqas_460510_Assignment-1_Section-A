#include<iostream>
#include<string>
using namespace std;
int main() {
    string s1, s2;
    
    cout << "Enter the first string: ";
    cin >> s1;
    cout << "Enter the second string: ";
    cin >> s2;
    if(s1==s2)
    {
    	int lens2 = s2.length();
    	string revs2;
    	for(int i=lens2 - 1; i>=0; i--)
    	{
    		revs2 += s2[i];
		}
		
		cout<<"The strings are equal so reversing one of the strings(2nd)"<<endl;
		cout<<"the first string is : "<<s1<<endl;
		cout<<"the second string is(now) : "<<revs2;
    	
	}
	else
	{
		cout<<"The strings are not equal";
	}
return 0;
}
