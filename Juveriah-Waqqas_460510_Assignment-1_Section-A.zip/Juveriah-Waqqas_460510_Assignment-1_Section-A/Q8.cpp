#include<iostream>
using namespace std;
int main()
{
	int elements=5, new_elements;
	int array[elements]={1,2,3,4,5};
	
	cout<<"The already present array before addition of new elements is : ";
	for(int i=0; i<elements; i++)
	{
		cout<<array[i]<<" ";
	}
	cout<<endl;
	
	cout<<"Enter the number of new elements you want to add : ";
	cin>>new_elements;
	
	elements = elements + new_elements;
	
	cout<<"Input the new elements one by one : "<<endl;
	for(int i=5; i<elements; i++)
	{
		cin>>array[i];
	}
	
	cout<<"The complete array after addition of new elements is : ";
	for(int i=0; i<elements; i++)
	{
		cout<<array[i]<<" ";
	}
		
return 0;	
}


