#include<iostream>
using namespace std;
int main()
{
	bool is_true;
	cout<<"Is this integer greater than 10 and less than equal to 20?"<<endl;
	int num;
	cout<<"Input the integer : ";
	cin>>num;
	
	if(num>10 && num<=20)
		{is_true=true;
		cout<<is_true<<" (yes the integer is greater than 10 and less than equal to 20)";}
	
	else
		{is_true=false;
		cout<<is_true<<" (no the integer isn't greater than 10 and less than equal to 20)";}
		
return 0;	
}





